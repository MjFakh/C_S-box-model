%% ---- Ocean-atmosphere box model for global Carbon and Sulfur Cyle ----
% ---- The unit of time is **100kyr** ------
% ---- The unit of amount is **Gmol** -----

clear all
tic

% -----------------------------------
% -------  SET PARAMETERS -----------
% -----------------------------------
% ---------------- Flux values -----------

F_carb              = 12 * 1E3 *1E5;                 % riverine carbonate flux 10 Tmol/yr (Gmol/100kyr year)
F_silic_land        = 10 * 1E3 *1E5;                 % riverine silicate flux 10 Tmol/yr (Gmol/100kyr year)
F_silic_marine      = 10 * 1E3 *1E5;                 % riverine silicate flux 10 Tmol/yr (Gmol/100kyr year)
F_silic_rev_marine  = 1 * 1E3 *1E5;                  % riverine silicate flux 10 Tmol/yr (Gmol/100kyr year)
F_POCweath          = 9 * 1E3 *1E5; 
Fvolc               = 400*1E5;                       % Total volcanic flux to the ocean 9E11 mol/yr
Fweath              = 2500*1E5;                      % Weathering flux 2E12 mol/yr
Fhydrotherm         = 500 *1E5;                      % hydrothermal input of S to the ocean 720 Gmol/yr
F_gypsum            = 2000*1E5;                      % Modern gypsum flux

% ------- Sediment DIC and TA flux -------

R_DIC_TA_coastal_oxic   = 1.75;                      % ratio of DIC to TA benthic flux resutled from diagenetic modeling (coastal sediment with oxic bottom water)
R_DIC_TA_deep_oxic      = 17;                        % DIC/TA benthic flux (deep sediment with oxic bottom water)
R_DIC_TA_coastal_anoxic = 1.02;                      % DIC/TA benthic flux (coastal sediment with anoxic bottom water)
R_DIC_TA_deep_anoxic    = 1.1;                       % DIC/TA benthic flux (deep sediment with anoxic bottom water)
fprod                   = 1;                         % factor for marine net primary production 

% ------- Weathering feedback parameters -------

pCO2_1     = 280 * 1E-6;
DIC_1      = 2000;
ALK_1      = 2400;
pCO2_marine_1 = CO2_gas(ALK_1,DIC_1);

apha_Carb  = 0.4;                % from LOSCAR
apha_silic = 0.2;                % from LOSCAR
alpha_organic = 0.5;

% ------- CO2 gas exchange parameters -------

SCO2    = 34000*1E-6*1E-9*1E3;       % CO2 solubility (uM/atm) Gmol/m3/atm 
KCO2_T  = 2800;                      % Temperature dependency CO2 solubility 
SST_1   = 25;
SST_2   = 4;
Temp1   = SST_1 + 273.15;    % Celciuc to Kelvin
Temp2   = SST_2 + 273.15;    % Celciuc to Kelvin
KHenry1 = SCO2.* exp(KCO2_T.*(1/Temp1 - 1/298.15));    %Correction of Henry's constant for Temperature
KHenry2 = SCO2.* exp(KCO2_T.*(1/Temp2 - 1/298.15));
kwCO2   = 0.2*24*365*1E5;                              % Piston velocity for CO2 (m/hr) m/100ky

% ------------------ Sulfur parameters -------------------

Km       = 10*1E-6*1E-9*1E3;                 % Monod for SR 5 uM  
SRdeep   = 1E-4 *1E-3*1E-9 *1E4*1E5;         % modern rate of SR in deep 5E-5 mmol/cm2/y
SRcoast  = 1E-3 *1E-3*1E-9 *1E4*1E5;         % modern rate of SR in coastal 5E-1 mmol/cm2/y
Vmax1    = 3E-1*1E-3*1E4*1E-9*1E5;           % Max SR in WC 1E-8 mmol/cm2/yr
Fe1      = 10;                               % Iron concentration (uM)
kFe      = 20;                               % constant for pyrite burial

% ------- Carbonate precipitation parameters -------

Calcium_activity = 0.6;                                                 % activity coefficient for Ca
Calcium          = 10000 * 1E3 * 1E-6 * 1E-9;                           % Ca concentration (uM) (Gmol/m3)
k_calcite        = 0.0003 * 1E-6 * 1E-9 * 1E3 * 1E5;                    % rate constant for calcite precipitation [uM-1 year-1] (Gmol/m3/100kyr)
Ksp_ca           = 500000 * 1E3 * 1E-6 * 1E-9 * 1E3 * 1E-6 * 1E-9;      % solubility product for calcite [uM^2] ((Gmol/m3)^2)
b_carb           = 1.7;
NPP_modern       = 26 * (1/12) * 1E-9 * 1E5;                            % modern NPP for open ocean (200 gC/m2/year) (Gmol/m2/100kyr)
Rain_ratio       = 0.05;                                                % Rain ratio (0.02-0.1; Sarmiento et al. 2002)

% ------- ODE parameters ------ 

tmax     = 40;          % final time in 10^6a  
maxstep  = 0.01;        % maximum step for integration (10^4a)

% ------- Other parameters ------ 

A_coast = 3.5*1e7*1e6;      % m2  coastal area
AREAtot = 3.75E14;          % m2
A_deep = AREAtot - A_coast; % m2 deep ocean area
Vtotal = 2E18;              % m3

% ----------------------------------
% ------- SIMULATION  --------------
% ----------------------------------
t0    = 0;                               % initial time  
% -------------- DIC ---------------
DIC10 = 1900*1E-6*1E-9*1E3  *Vtotal;     % initial amounts in Gmol
DIC20 = 280 * 1E-6;                      % initial amounts of CO2 in atm
% -------------- TA ----------------
TA10  = 2400*1E-6*1E-9*1E3  *Vtotal;     % initial amounts in Gmol
% ------------- SO4 ----------------
S10   = 28000E-6*1E-9*1E3  *Vtotal; 
% ------------ time ---------------
T10 = 0; % time

W0 = [DIC10 DIC20 TA10 S10 T10]';

DIC1conc = @(W)  W(1)/Vtotal;   % DIC concentration Gmol/m3
DIC2conc = @(W)  W(2);          % initial amounts of CO2 in atm
TA1conc  = @(W)  W(3)/Vtotal;   % TA concentration Gmol/m3
S1conc   = @(W)  W(4)/Vtotal;   % TA concentration Gmol/m3
T1       = @(W)  W(5);          % Time

% ------------------------------------------------------------
% ----------------- CO2 Air-sea Gas Exchange Flux ------------
% ------------------------------------------------------------
CO2gas_1 = @ (W,t) CO2_gas((TA1conc(W) * 1E6 * 1E9 * 1E-3),(DIC1conc(W) * 1E6 * 1E9 * 1E-3));
AM1      = @ (W,t) kwCO2*((CO2gas_1(W,t) * KHenry1 * 1E-6)-(DIC2conc(W) * KHenry1))*AREAtot;   % Ocean-Atmos CO2 exchange continental
% ----------------------------------------
% ------ Weathering feedback -------------
% ----------------------------------------
F_carb_1         = @(W,t) 2 * F_carb * (DIC2conc(W)./pCO2_1).^apha_Carb;         % revised carbonate weathering flux
F_silic_land1    = @(W,t) F_silic_land * (DIC2conc(W)./pCO2_1).^apha_silic;       % revised silicate weathering flux
F_silic_marine1  = @(W,t) F_silic_marine * ((CO2_gas((TA1conc(W) * 1E6 * 1E9 * 1E-3),(DIC1conc(W) * 1E6 * 1E9 * 1E-3)))./pCO2_marine_1).^apha_silic;       % revised silicate weathering flux
% ---------------------------------------------------------
% --------- CO2 degassing dynamic  ------------------------
% ---------------------------------------------------------
F_degass  = @(W,t) 8 * 1E3 *1E5;
% ---------------------------------------------------------
% --------- Areal fraction of oxic and anoxia  ------------
% ---------------------------------------------------------
f1_anoxia = 0.001;
f_anoxia  = @(W,t) f1_anoxia; 
f_oxic    = @(W,t) (1 - f_anoxia(W,t));
% ---------------- fraction of anoxia ---------------------
f_area_total_anoxic = @(W,t) f_anoxia(W,t) * AREAtot;
% ---------------- fraction of oxic -----------------------
f_area_total_oxic   = @(W,t) f_oxic(W,t) * AREAtot;
% ---------------------------------------------------------
% -------------------------------
% ------------ DIC --------------
% -------------------------------
BE_oxic       = 0.027;           % Burial efficiency
BE_anoxic     = 0.1;             % Burial efficiency
BE_WC_modern  = 0.027;
BE_sed        = 0.315;
BE_WC         = @(W,t) f_anoxia(W,t) * BE_anoxic + f_oxic(W,t) * BE_oxic;
f_oxic_modern = 1-0.001;
NPP_1         = @(W,t) fprod * NPP_modern * ((F_silic_land1(W,t)./F_silic_land).^alpha_organic);
F_DIC1_modern = NPP_modern * BE_WC_modern.*BE_sed.*AREAtot; 
F_DIC1        = @(W,t)  NPP_1(W,t) * BE_WC(W,t).*BE_sed.*AREAtot; 
F_POCweath_1  = @(W,t) F_POCweath * ((F_DIC1(W,t)./F_DIC1_modern).^alpha_organic);
% --------------------------------------------------------
% --------- DIC flux from sediment -----------------------
% --------------------------------------------------------
Fsed1_DIC     = @(W,t) (1-BE_sed).* NPP_1(W,t) * f_oxic(W,t) * BE_WC(W,t).*AREAtot;
% ----------------------------------------
% ------ Carbonate precipitation ---------
% ----------------------------------------

% Biogenic
Flux_org_1       = @(W,t) NPP_1(W,t);
Flux_carb_bio_1  = @(W,t)  f_oxic(W,t).* Flux_org_1(W,t).*Rain_ratio.*AREAtot;    

% Authigenic
CO3_1            = @ (W,t) (Carb_CO3((TA1conc(W) * 1E6 * 1E9 * 1E-3),(DIC1conc(W) * 1E6 * 1E9 * 1E-3))) * 1E-6 * 1E-9 * 1E3;
sigma_carb_1     = @(W,t) (Calcium_activity.*Calcium.* CO3_1(W,t))./(Ksp_ca) - 1;
K_sigma_1        = @(W,t) (sigma_carb_1(W,t)).^b_carb;
Flux_carb_auth_1 = @(W,t)  K_sigma_1(W,t).*k_calcite.*Vtotal;   

% ---------------------------------------------------------
% ------------------- Pyrite burial -----------------------
% ---------------------------------------------------------

% Water Column
F_pyr = @(W,t) (NPP_1(W,t)./NPP_modern).*Vmax1.* (S1conc(W)/(S1conc(W) + Km)).* ...
               (Fe1/(Fe1 + kFe)).*(F_silic_land1(W,t)./F_silic_land).*...
               f_anoxia(W,t).*AREAtot;

% Sediment
Fsed_pyr = @(W,t) (Fe1/(Fe1 + kFe)).* (NPP_1(W,t)./NPP_modern).* (A_coast.*SRcoast + A_deep.*SRdeep); 

% -------------------------------------------------------------------------
% ---------------------- Gypsum burial ------------------------------------
% -------------------------------------------------------------------------

F_gypsum1 = F_gypsum./Vtotal;
Modern_SO4 = 28000 * 1E3 * 1E-6 * 1E-9; %Gmol/m3
Modern_Ca = 10000 * 1E3 * 1E-6 * 1E-9; %Gmol/m3
Ca1 = 10000 * 1E3 * 1E-6 * 1E-9; %Gmol/m3

F_gyp = @(W,t) F_gypsum1 * Vtotal * ((S1conc(W) * Ca1)./(Modern_SO4 * Modern_Ca));

% ---------------------------------------------------------
% ------------- SETTING UP THE ODEs -----------------------
% ---------------------------------------------------------

% ----------- DIC ------------------
dDIC1dt  = @(t,W) F_carb_1(W,t)  + F_silic_land1(W,t) - F_DIC1(W,t)...
                  - 0.5.*Flux_carb_auth_1(W,t) - 0.5.*Flux_carb_bio_1(W,t) - AM1(W,t);
dDIC2dt  = @(t,W) AM1(W,t) - 0.5 * F_carb_1(W,t) - F_silic_land1(W,t) + F_degass(W,t) + F_POCweath_1(W,t);    
% ----------- TA -------------------
dTA1dt  = @(t,W) F_carb_1(W,t)  + F_silic_land1(W,t) + F_silic_marine1(W,t) + 2.*F_pyr(W,t) + 2.*Fsed_pyr(W,t) - ...
                 Flux_carb_auth_1(W,t) - Flux_carb_bio_1(W,t) - F_silic_rev_marine;       
% ------------- SO4 ----------------
dS1dt  = @(t,W) Fvolc + Fweath - F_pyr(W,t) - Fsed_pyr(W,t) - F_gyp(W,t);             
% ------------ time ----------------
% Time series
dTdt = @(t,W) 1;
% ---------------------------------------------------------
% ----- Call the numerical solver  ------------------------
% ---------------------------------------------------------
dWdt    = @(t,W) [dDIC1dt(t,W) dDIC2dt(t,W) dTA1dt(t,W) dS1dt(t,W) dTdt(t,W)]' ;   % define the derivative 
options = odeset('MaxStep',maxstep);                                               % set solver options
[T,Y]   = ode15s(dWdt,[t0 tmax],W0,options);                                       % call the solver (using stiff solver)
% ---------------------------------------------------------
% -------------- FLUX AND CONC. CALCULATION ---------------
% ---------------------------------------------------------

% DIC
DIC1c = (Y(:,1)*1E6*1E9)./1E3 /Vtotal;  % concentrations in uM
DIC2c = Y(:,2)*1E6;              % concentrations in ppm

%TA
TA1c = (Y(:,3)*1E6*1E9)./1E3 /Vtotal;  % concentrations in uM

%SO4
SO4c = (Y(:,4)*1E6*1E9)./1E3 /Vtotal;  % concentrations in uM

        for i=1:size(T,1)
        
            wF_DIC1(i) = 1E-8 * F_DIC1(Y(i,:),T(i));
            wF_pyr(i) = 1E-8 * F_pyr(Y(i,:),T(i));
            wF_TA1(i) = 2.* wF_pyr(i);
            wFsed_pyr(i) = 1E-8 * Fsed_pyr(Y(i,:),T(i));
            wsed1_DIC(i) = 1E-8 * Fsed1_DIC(Y(i,:),T(i));
            wsed1_TA(i) = 2.* wFsed_pyr(i);
            WF_carb_1(i) = 1E-8 * F_carb_1(Y(i,:),T(i));
            WF_silic_land1(i)= 1E-8 * F_silic_land1(Y(i,:),T(i));
            WF_silic_marine1(i)= 1E-8 * F_silic_marine1(Y(i,:),T(i));
            wK_sigma_1(i) = K_sigma_1(Y(i,:),T(i));
            wsigma_carb_1(i) = sigma_carb_1(Y(i,:),T(i));
            wCO3_11(i) = Carb_CO3(TA1c(i),DIC1c(i));
            wFlux_carb_auth_1(i) = 1E-8 * Flux_carb_auth_1(Y(i,:),T(i));
            wFlux_carb_bio_1(i) = 1E-8 * Flux_carb_bio_1(Y(i,:),T(i));
            pH_1(i)   = carbonate(TA1c(i),DIC1c(i));
            wAM1(i) = 1E-8 *AM1(Y(i,:),T(i));
            WNPP(i) = NPP_1(Y(i,:),T(i));
            wFlux_org_1(i) = Flux_org_1(Y(i,:),T(i));
            WPOC_weath(i) = 1E-8 *F_POCweath_1(Y(i,:),T(i));
            wF_DIC1(i) = 1E-8.*F_DIC1(Y(i,:),T(i));
            wCO2gas_1(i) = CO2_gas(TA1c(i),DIC1c(i));
            wfanoxia(i) = f_anoxia(Y(i,:),T(i));
            wF_degass(i) = 1E-8 * F_degass(Y(i,:),T(i));
            wf_oxic(i)  = f_oxic(Y(i,:),T(i));
        
        end
  
% ---------------------------------------------------------
% -------------- PLOT RESULTS  ----------------------------
% ---------------------------------------------------------

linewidth = 2;
Fontsize = 12;

subplot(3,2,1)
plot(T,DIC1c,'lineWidth',linewidth);
set(gca, 'FontName', 'Arial','FontSize', Fontsize,'lineWidth',linewidth);
ylabel ('DIC (\muM)' );
xlabel ('time (10^5 yr)');
ylim([1000 3000]);

subplot(3,2,2)
plot(T,TA1c,'lineWidth',linewidth);
set(gca, 'FontName', 'Arial','FontSize', Fontsize,'lineWidth',linewidth);
ylabel ('TA (\muM)' );
xlabel ('time (10^5 yr)');
ylim([1000 3000]);

subplot(3,2,3)
plot(T,DIC2c,'lineWidth',linewidth);
set(gca, 'FontName', 'Arial','FontSize', Fontsize,'lineWidth',linewidth);
ylabel ('pCO_2 (ppm)' );
xlabel ('time (10^5 yr)');
ylim([0 1.5*max(DIC2c)]);

subplot(3,2,4) 
plot(T,pH_1,'lineWidth',linewidth);
set(gca, 'FontName', 'Arial','FontSize', Fontsize,'lineWidth',linewidth); 
ylabel ('pH');
xlabel ('time (10^5 yr)');
ylim([7 9]);

subplot(3,2,5) 
plot(T,SO4c,'lineWidth',linewidth);
set(gca, 'FontName', 'Arial','FontSize', Fontsize,'lineWidth',linewidth);
ylabel ('SO4 (\muM)' );
xlabel ('time (10^5 yr)');
ylim([10000 30000]);

subplot(3,2,6) 
plot(T,wFsed_pyr+wF_pyr,'lineWidth',linewidth);
set(gca, 'FontName', 'Arial','FontSize', Fontsize,'lineWidth',linewidth);
ylabel ('F_{pyr} Tmol yr^{-1}' );
xlabel ('time (10^5 yr)');
ylim([0 2]);
